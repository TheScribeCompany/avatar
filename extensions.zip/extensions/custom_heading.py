import os
import sys

# Add the extensions folder to the system path
sys.path.append(os.path.abspath('./extensions'))
