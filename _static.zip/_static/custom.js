
/* drop down menu*/

function showContent(contentId) {
    // Hide all content items
    var contentItems = document.querySelectorAll('.content-item');
    contentItems.forEach(function (item) {
        item.style.display = 'none';
    });

    // Show the selected content item
    var selectedContent = document.getElementById(contentId);
    if (selectedContent) {
        selectedContent.style.display = 'block';
    }
}

// Tab switching function
function openTab(evt, tabName) {
    // Hide all tab content
    var tabcontents = document.querySelectorAll(".tabcontent");
    tabcontents.forEach(function (tabcontent) {
        tabcontent.style.display = "none";
    });

    // Remove the active class from all tab links
    var tablinks = document.querySelectorAll(".tablink");
    tablinks.forEach(function (tablink) {
        tablink.classList.remove("active");
    });

    // Display the current tab content and add active class to the button
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.classList.add("active");
}

// Copy function
function copyCode() {
    const code = document.querySelector("#Tab1 pre").innerText;
    navigator.clipboard.writeText(code).then(function() {
        alert("Code copied to clipboard!");
    }).catch(function(error) {
        console.error("Error copying code: ", error);
    });
}

// Automatically open the first tab
document.addEventListener("DOMContentLoaded", function() {
    document.querySelector(".tablink").click();
});

